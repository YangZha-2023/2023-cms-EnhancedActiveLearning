import os
import sys
# linux need open
sys.path.append(os.path.realpath('..'))
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE
from sklearn.metrics import r2_score
from sklearn.model_selection import GridSearchCV
from sklearn.decomposition import PCA
import pandas as pd
import time
from copy import deepcopy
import numpy as np
import joblib


def ridge_regression(_x_train, _y_train, _x_test, _y_test):

    from sklearn.linear_model import Ridge

    start_ridge = time.time()

    _cv = 5
    _alpha_range = np.arange(1, 1001, 100)
    _param = {'alpha': _alpha_range}

    _std_x_train, _scaler_x_train = standardscaler(_x_train, _x_train)
    _std_y_train, _scaler_y_train = standardscaler(_y_train.ravel(), _y_train.ravel())
    _std_x_test = _scaler_x_train.transform(_x_test)

    _gs = GridSearchCV(estimator=Ridge(), param_grid=_param,
                       scoring='neg_mean_squared_error', n_jobs=n_jobs,
                       cv=_cv, refit=True)

    _criteria = _gs.fit(_std_x_train, _std_y_train.ravel())

    _best_params = _criteria.best_params_
    _alpha = _best_params['alpha']

    end_ridge = time.time()
    ridge_time = (end_ridge - start_ridge) / 60
    with open("../model/%s/%dloop_%s.txt" % (data_name, nth_cv, version), "a") as _f:
        _f.write("Ridge: Round %d: alpha = %f The ridge regression spend time: %0.2f minute!\n" % (nth_cv,
                                                                                                   _alpha, ridge_time))

    joblib.dump(_criteria, '../model/%s/ridge_%dloop_%s.dat' % (data_name, nth_cv, version))

    _y_predict = _criteria.predict(_std_x_test)

    _test_r2 = r2_score(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_mae = MAE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_rmse = np.sqrt(MSE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel()))

    return _test_r2, _test_mae, _test_rmse


def gpr_regression(_x_train, _y_train, _x_test, _y_test):

    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF

    start_gpr = time.time()

    _cv = 5
    _param = {'random_state': [10, 100]}

    _std_x_train, _scaler_x_train = standardscaler(_x_train, _x_train)
    _std_y_train, _scaler_y_train = standardscaler(_y_train.ravel(), _y_train.ravel())
    _std_x_test = _scaler_x_train.transform(_x_test)

    _gs = GridSearchCV(estimator=GaussianProcessRegressor(kernel=RBF(length_scale=1)), param_grid=_param,
                       scoring='neg_mean_squared_error', n_jobs=n_jobs,
                       cv=_cv, refit=True)

    _criteria = _gs.fit(_std_x_train, _std_y_train.ravel())


    end_gpr = time.time()
    gpr_time = (end_gpr - start_gpr) / 60
    with open("../model/%s/%dloop_%s.txt" % (data_name, nth_cv, version), "a") as _f:
        _f.write("GPR: Round %d: The GPR regression spend time: %0.2f minute!\n" % (nth_cv, gpr_time))

    joblib.dump(_criteria, '../model/%s/gpr_%dloop_%s.dat' % (data_name, nth_cv, version))

    _y_predict = _criteria.predict(_std_x_test)

    _test_r2 = r2_score(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_mae = MAE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_rmse = np.sqrt(MSE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel()))

    return _test_r2, _test_mae, _test_rmse


def svr_regression(_x_train, _y_train, _x_test, _y_test):

    from sklearn.svm import SVR

    start_svr = time.time()

    _cv = 5
    _c_range = np.linspace(1, 200, 20)
    _param = {'epsilon': [0.01],
              'gamma': np.logspace(-4, -2, 20),
              'C': _c_range}

    _std_x_train, _scaler_x_train = standardscaler(_x_train, _x_train)
    _std_y_train, _scaler_y_train = standardscaler(_y_train.ravel(), _y_train.ravel())
    _std_x_test = _scaler_x_train.transform(_x_test)

    _gs = GridSearchCV(estimator=SVR(), param_grid=_param,
                       scoring='neg_mean_squared_error', n_jobs=n_jobs,
                       cv=_cv, refit=True)

    _criteria = _gs.fit(_std_x_train, _std_y_train.ravel())

    _best_params = _criteria.best_params_
    _epsilon = _best_params['epsilon']
    _gamma = _best_params['gamma']
    _C = _best_params['C']

    end_svr = time.time()
    svr_time = (end_svr - start_svr) / 60
    with open("../model/%s/%dloop_%s.txt" % (data_name, nth_cv, version), "a") as _f:
        _f.write("SVR: Rounds %d: epsilon = %f, gamma = %f, C = %f The SVR regression spend time: %0.2f minute!\n" %
                 (nth_cv, _epsilon, _gamma, _C, svr_time))

    joblib.dump(_criteria, '../model/%s/svr_%dloop_%s.dat' % (data_name, nth_cv, version))

    _y_predict = _criteria.predict(_std_x_test)

    _test_r2 = r2_score(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_mae = MAE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_rmse = np.sqrt(MSE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel()))

    return _test_r2, _test_mae, _test_rmse


def gbr_regression(_x_train, _y_train, _x_test, _y_test):

    # ConvergenceWarning: lbfgs failed to converge (status=2):ABNORMAL_TERMINATION_IN_LNSRCH
    from sklearn.ensemble import GradientBoostingRegressor

    start_gbr = time.time()

    _cv = 5

    _param = {'n_estimators': np.arange(100, 1000, 10), 'random_state': [20]}

    _std_x_train, _scaler_x_train = standardscaler(_x_train, _x_train)
    _std_y_train, _scaler_y_train = standardscaler(_y_train.ravel(), _y_train.ravel())
    _std_x_test = _scaler_x_train.transform(_x_test)

    _gs = GridSearchCV(estimator=GradientBoostingRegressor(), param_grid=_param,
                       scoring='neg_mean_squared_error', n_jobs=n_jobs,
                       cv=_cv, refit=True)

    _criteria = _gs.fit(_std_x_train, _std_y_train.ravel())

    _best_params = _criteria.best_params_
    _n_estimators = _best_params['n_estimators']
    # _max_depth = _best_params['max_depth']
    _random = _best_params['random_state']

    end_gbr = time.time()
    gbr_time = (end_gbr - start_gbr) / 60
    with open("../model/%s/%dloop_%s.txt" % (data_name, nth_cv, version), "a") as _f:
        _f.write("GBR: Rounds %d: n_estimators = %d, random_state = %d The GBR regression spend time: %0.2f minute!\n" %
                 (nth_cv, _n_estimators, _random, gbr_time))

    joblib.dump(_criteria, '../model/%s/gbr_%dloop_%s.dat' % (data_name, nth_cv, version))

    _y_predict = _criteria.predict(_std_x_test)

    _test_r2 = r2_score(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_mae = MAE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_rmse = np.sqrt(MSE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel()))

    return _test_r2, _test_mae, _test_rmse


def rfr_regression(_x_train, _y_train, _x_test, _y_test):

    from sklearn.ensemble import RandomForestRegressor

    start_rfr = time.time()

    _cv = 5
    _param = {'n_estimators': np.arange(10, 200, 10), 'random_state': [20]}
    _std_x_train, _scaler_x_train = standardscaler(_x_train, _x_train)
    _std_y_train, _scaler_y_train = standardscaler(_y_train.ravel(), _y_train.ravel())
    _std_x_test = _scaler_x_train.transform(_x_test)

    _gs = GridSearchCV(estimator=RandomForestRegressor(), param_grid=_param,
                       scoring='neg_mean_squared_error', n_jobs=n_jobs,
                       cv=_cv, refit=True)

    _criteria = _gs.fit(_std_x_train, _std_y_train.ravel())

    _best_params = _criteria.best_params_
    _n_estimators = _best_params['n_estimators']
    _random = _best_params['random_state']

    end_rfr = time.time()
    rfr_time = (end_rfr - start_rfr) / 60
    with open("../model/%s/%dloop_%s.txt" % (data_name, nth_cv, version), "a") as _f:
        _f.write("RFR: Rounds %d: n_estimators = %d, random_state = %d The RFR regression spend time: %0.2f minute!\n" %
                 (nth_cv, _n_estimators, _random, rfr_time))

    joblib.dump(_criteria, '../model/%s/rfr_%dloop_%s.dat' % (data_name, nth_cv, version))

    _y_predict = _criteria.predict(_std_x_test)

    _test_r2 = r2_score(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_mae = MAE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel())
    _test_rmse = np.sqrt(MSE(_y_test, _scaler_y_train.inverse_transform(_y_predict.reshape(-1, 1)).ravel()))

    return _test_r2, _test_mae, _test_rmse


def standardscaler(_df_data, _X_labeled):
   
    from sklearn.preprocessing import StandardScaler
    if len(_df_data.shape) == 2:

        scaler_data = StandardScaler().fit(_df_data)
        std_X = scaler_data.transform(_X_labeled)
        return std_X, scaler_data
    elif len(_df_data.shape) == 1:
 
        _scaler_y = StandardScaler().fit(_df_data.reshape(-1, 1))
        _std_y = _scaler_y.transform(_df_data.reshape(-1, 1))
        return _std_y, _scaler_y


if __name__ == '__main__':

    data_name = 'Cr-Fe-Co-Ni'

    version = 'V1'
    gl_cv = 5
    n_jobs = 14  # bsub

    system_path = '../data/%s.csv' % data_name
    df_all = pd.read_csv(filepath_or_buffer=system_path, index_col=0)

    gl_TTS_seed_num = 10

    print("system: %s\n" % data_name)

    with open("%s_processing_%dtimescv_%s.txt" % (data_name, gl_TTS_seed_num, version), "a") as f:
        f.write("system: %s\n" % data_name)

    X_binary = df_all.iloc[:180, 1:].values
    y_binary = df_all.iloc[:180, 0].values

    X_multicomponent = df_all.iloc[180:, 1:]
    y_multicomponent = df_all.iloc[180:, 0]
    
    start_10 = time.time()

    results_holder = {'Ridge': [], 'RFR': [], 'GPR': [], 'GBR': [], 'SVR': []}
    all_results_mae = deepcopy(results_holder)
    all_results_rmse = deepcopy(results_holder)
    all_results_r2 = deepcopy(results_holder)

    nth_cv = 1

    # for TTS_seed in np.random.randint(10000, size=10):
    for TTS_seed in np.random.randint(10000, size=10):

        start_cv = time.time()

        print("Start %d CV, TTS_seed: %d\n" % (nth_cv, TTS_seed))
        with open("%s_processing_%dtimescv_%s.txt" % (data_name, gl_TTS_seed_num, version), "a") as f:
            f.write("Start %d CV, TTS_seed: %d\n" % (nth_cv, TTS_seed))

        TTS_test_size = 0.2    

        X_multicomponent_train, X_multicomponent_test, y_multicomponent_train, y_multicomponent_test = \
            train_test_split(X_multicomponent.values, y_multicomponent.values,
                             test_size=TTS_test_size, random_state=TTS_seed, shuffle=True)

        X_train = np.concatenate((X_binary, X_multicomponent_train), axis=0)

        y_train = np.concatenate((y_binary, y_multicomponent_train))

        # Ridge
        _ridge_test_r2, _ridge_test_mae, _ridge_test_rmse = \
            ridge_regression(X_train, y_train, X_multicomponent_test, y_multicomponent_test)

        all_results_r2['Ridge'].append(_ridge_test_r2)
        all_results_mae['Ridge'].append(_ridge_test_mae)
        all_results_rmse['Ridge'].append(_ridge_test_rmse)

        # RFR
        _rfr_test_r2, _rfr_test_mae, _rfr_test_rmse = \
            rfr_regression(X_train, y_train, X_multicomponent_test, y_multicomponent_test)

        all_results_r2['RFR'].append(_rfr_test_r2)
        all_results_mae['RFR'].append(_rfr_test_mae)
        all_results_rmse['RFR'].append(_rfr_test_rmse)

        # GPR
        _gpr_test_r2, _gpr_test_mae, _gpr_test_rmse = \
            gpr_regression(X_train, y_train, X_multicomponent_test, y_multicomponent_test)

        all_results_r2['GPR'].append(_gpr_test_r2)
        all_results_mae['GPR'].append(_gpr_test_mae)
        all_results_rmse['GPR'].append(_gpr_test_rmse)

        # GBR
        _gbr_test_r2, _gbr_test_mae, _gbr_test_rmse = \
            gbr_regression(X_train, y_train, X_multicomponent_test, y_multicomponent_test)

        all_results_r2['GBR'].append(_gbr_test_r2)
        all_results_mae['GBR'].append(_gbr_test_mae)
        all_results_rmse['GBR'].append(_gbr_test_rmse)

        # SVR
        _svr_test_r2, _svr_test_mae, _svr_test_rmse = \
            svr_regression(X_train, y_train, X_multicomponent_test, y_multicomponent_test)

        all_results_r2['SVR'].append(_svr_test_r2)
        all_results_mae['SVR'].append(_svr_test_mae)
        all_results_rmse['SVR'].append(_svr_test_rmse)

        end_cv = time.time()
        ith_cv_time = (end_cv - start_cv)/60
        print('>>>>>>>>>>The %d CV is over! spend time: %0.2f minute\n' % (nth_cv, ith_cv_time))
        with open("%s_processing_%dtimescv_%s.txt" % (data_name, gl_TTS_seed_num, version), "a") as f:
            f.write('>>>>>>>>>>The %d cv is over! spend time: %0.2f minute\n' % (nth_cv, ith_cv_time))

        nth_cv += 1

    finish_cv = time.time()
    all_cv_time = (finish_cv - start_10)/3600
    print('Total time: %0.2f hour' % all_cv_time)
    with open("%s_processing_%dtimescv_%s.txt" % (data_name, gl_TTS_seed_num, version), "a") as f:
        f.write('Total CV time: %0.2f hour\n' % all_cv_time)

    data_r2 = np.array(list(all_results_r2.values()))
    index_name_r2 = ['Ridge_r2', 'RFR_r2', 'GPR_r2', 'GBR_r2', 'SVR_r2']

    data_mae = np.array(list(all_results_mae.values()))
    index_name_mae = ['Ridge_mae', 'RFR_mae', 'GPR_mae', 'GBR_mae', 'SVR_mae']

    data_rmse = np.array(list(all_results_rmse.values()))
    index_name_rmse = ['Ridge_rmse', 'RFR_rmse', 'GPR_rmse', 'GBR_rmse', 'SVR_rmse']

    df_excel_r2 = pd.DataFrame(data_r2, index=index_name_r2).T
    df_excel_mae = pd.DataFrame(data_mae, index=index_name_mae).T
    df_excel_rmse = pd.DataFrame(data_rmse, index=index_name_rmse).T

    df_excel_r2.to_csv('../results/%s/%s_data_for_draw_in_excel_%dtimmescv_r2_%s.csv'
                       % (version, data_name, gl_TTS_seed_num, version))
    df_excel_mae.to_csv('../results/%s/%s_data_for_draw_in_excel_%dtimmescv_mae_%s.csv'
                        % (version, data_name, gl_TTS_seed_num, version))
    df_excel_rmse.to_csv('../results/%s/%s_data_for_draw_in_excel_%dtimmescv_rmse_%s.csv'
                         % (version, data_name, gl_TTS_seed_num, version))

