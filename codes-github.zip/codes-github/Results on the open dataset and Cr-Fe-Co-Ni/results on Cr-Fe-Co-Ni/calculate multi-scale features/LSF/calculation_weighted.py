import pandas as pd
import numpy as np
import time


def bash_component():

    df_component = pd.read_csv("./composition.csv", index_col=0)

    df_properties = pd.read_csv("./properties.csv", index_col=0)

    matrix1 = df_component.values

    names = df_component.columns.tolist()

    features = df_properties.columns.tolist()

    numbers = df_component.index.tolist()

    matrix2 = df_properties.values

    results = np.matmul(matrix1, matrix2)

    df_results = pd.DataFrame(data=results, columns=features, index=numbers)

    return df_results


if __name__ == '__main__':

    df_result = bash_component()

    df_result.to_csv('./LSF_feature.csv')

