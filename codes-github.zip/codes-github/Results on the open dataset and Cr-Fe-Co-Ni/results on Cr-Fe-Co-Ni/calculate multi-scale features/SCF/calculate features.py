import pandas as pd
import numpy as np
import time


def make_new_sequence(component):

    element_type = list()

    element_type_5sl = list()

    for values in sequence_table.values:
        for position in values:
            element_type_5sl.append(position)

    for a in range(1, 31):
        if a <= 2:
            element_type.append(component[0])
        elif a <= 6:
            element_type.append(component[1])
        elif a <= 14:
            element_type.append(component[2])
        elif a <= 22:
            element_type.append(component[3])
        else:
            element_type.append(component[4])

    df_temp = sequence_table.copy()

    df_temp['element'] = element_type

    return df_temp


def neighbour_atom(df_sequence):

    df_center = df_sequence.copy()
    del df_center['position']

    df_neighbour = neighbour_table.iloc[:, 16:]

    df_areas = neighbour_table.iloc[:, 1:16]

    surface_areas = neighbour_table.iloc[:, 0]

    for atom in range(1, 31):
        for j in df_neighbour.columns.tolist():

            atom_n = df_neighbour.loc[atom, j]

            if atom_n > 0:

                df_neighbour.loc[atom, j] = df_sequence.loc[atom_n, 'element']
            else:
                continue

    return df_center, df_neighbour, df_areas, surface_areas


def add_property(_df_center, _df_neighbour, _properties):

    df_neighbour_properties = _df_neighbour.copy()

    for a in range(1, 31):
        for b in df_neighbour_properties.columns.tolist():
            if df_neighbour_properties.loc[a, b] != 0:

                keys = df_neighbour_properties.loc[a, b]
  
                df_neighbour_properties.loc[a, b] = element_properties.loc[keys, _properties]
            else:
                continue

    for x in range(1, 31):
        types = _df_center.loc[x, 'element']
        _df_center.loc[x, 'element'] = element_properties.loc[types, _properties]

    return _df_center, df_neighbour_properties


def calculate_property(_df_center_values, _df_neighbour_values, _df_areas, _surface_areas):
 
    matrix_neighbour_element = _df_neighbour_values.values
    matrix_center_element = _df_center_values.values
    matrix_areas = _df_areas.values
    matrix_total_areas = _surface_areas.values
    # print(matrix_total_areas.shape)

    # matrix_neighbour_element(30,15),matrix_center_element(30,1)
    # np.abs(matrix_neighbour_element - matrix_center_element),shape=(30,15),matrix_areas(30,15)
    array1 = np.abs(matrix_neighbour_element - matrix_center_element) * matrix_areas

    # array1,shape=(30,15), array1_sum,shape=(30,1)
    array1_sum = np.sum(array1, axis=1, dtype=np.float64)
    if np.sum(array1_sum) == 0:
        delta_P = np.zeros((5,))
        # print(delta_P)
        return delta_P
    else:
        # print(properties)
        deltaP_list = list()
        for i in [0, 2, 6, 14, 22]:

            if i == 0:
                deltaP_list.append((array1_sum[i] * 2) / matrix_total_areas[i])
            elif i == 2:
                deltaP_list.append((array1_sum[i] * 4) / matrix_total_areas[i])
            elif i == 6:
                deltaP_list.append((array1_sum[i] * 8) / matrix_total_areas[i])
            elif i == 14:
                deltaP_list.append((array1_sum[i] * 8) / matrix_total_areas[i])
            elif i == 22:
                deltaP_list.append((array1_sum[i] * 8) / matrix_total_areas[i])
        # print(deltaP_list)
        return deltaP_list


def occupancy_of_sublattice(_system, _attributes):
    df_position = pd.read_csv('./position_info/position_info_%s.csv' % _system, index_col=0)
    df_elements = pd.read_csv('./attributes_of_elements/attributes_of_elements_%s.csv' % _attributes, index_col=0)

    df_position.index = range(df_position.shape[0])

    array_concate_1 = []
    for i in df_position.index:
        array_concate_0 = np.array([])
        for y in df_position.columns:
            if y == '2a':
                element = df_position.loc[i, y]
                element_attributs = (df_elements.loc[element, :].values * 2) / 30
            elif y == '4f':
                element = df_position.loc[i, y]
                element_attributs = (df_elements.loc[element, :].values * 4) / 30
            elif y == '8i1':
                element = df_position.loc[i, y]
                element_attributs = (df_elements.loc[element, :].values * 8) / 30
            elif y == '8i2':
                element = df_position.loc[i, y]
                element_attributs = (df_elements.loc[element, :].values * 8) / 30
            elif y == '8j':
                element = df_position.loc[i, y]
                element_attributs = (df_elements.loc[element, :].values * 8) / 30
            array_concate_0 = np.concatenate((array_concate_0, element_attributs), axis=0)
        array_concate_1.append(array_concate_0)

    feature_col = []
    feature_index = df_position.index.tolist()
    for lattice in df_position.columns:
        for attributes in df_elements.columns:
            feature_col.append(attributes + '_' + lattice)
    # print(feature_col)
    df_feature = pd.DataFrame(data=np.array(array_concate_1),
                              index=feature_index,
                              columns=feature_col)

    name_list = np.unique(df_position.values)
    if len(name_list) == 2:
        names = name_list[0] + '-' + name_list[1]
    elif len(name_list) == 3:
        names = name_list[0] + '-' + name_list[1] + '-' + name_list[2]
    elif len(name_list) == 4:
        names = name_list[0] + '-' + name_list[1] + '-' + name_list[2] + '-' + name_list[3]

    return df_feature


if __name__ == '__main__':

 
    sequence_table = pd.read_csv('./sequence.csv', index_col=0)

    neighbour_table = pd.read_csv('./neighbour_atom.csv', index_col=0)

    neighbour_table.fillna(value=0, inplace=True)

    start1 = time.time()

    # ['Cr-Fe-Co', 'Cr-Fe-Ni', 'Mo-Re-Co', 'Mo-Re-Ni']
    for system in ['Cr-Fe-Co']:
        # start = time.time()
        start_system = time.time()

        component_table = pd.read_csv('./position_info/position_info_%s.csv' % system, index_col=0)

        component_table.index = range(component_table.shape[0])

        target_list = ['E_Nor1', 'E_Nor2', 'deltaH1', 'deltaH2']
        target_name = target_list[3]
        df_target = pd.read_csv('./target/%s.csv' % system, index_col=0)

        target_values = df_target.loc[:, target_name].values.reshape(-1, 1)
        # print(target_values)
        df_target = pd.DataFrame(data=target_values, columns=[target_name])
        # print(df_target)
        # ['ALL', 'noEIF', 'noED', 'noEA', 'noEV', 'noEC', 'noMAG', 'noVE']
        for attributes in ['ORI']:
            start_attribute = time.time()

            element_properties = pd.read_csv('./attributes_of_elements/attributes_of_elements_%s.csv' % attributes,
                                             index_col=0)
            # element_properties = pd.read_csv('./electric_all.csv', index_col=0)

            if component_table.shape[0] == 32:

                element_1 = component_table.loc[0, '2a']
                element_2 = component_table.loc[1, '2a']
                name = element_1 + '-' + element_2
            elif component_table.shape[0] == 153:

                element_1 = component_table.loc[0, '2a']
                element_2 = component_table.loc[1, '2a']
                element_3 = component_table.loc[2, '2a']
                name = element_1 + '-' + element_2 + '-' + element_3
            elif component_table.shape[0] == 243:

                element_1 = component_table.loc[0, '2a']
                element_2 = component_table.loc[1, '2a']
                element_3 = component_table.loc[2, '2a']
                name = element_1 + '-' + element_2 + '-' + element_3
            elif component_table.shape[0] == 244:

                element_1 = component_table.loc[0, '2a']
                element_2 = component_table.loc[1, '2a']
                element_3 = component_table.loc[2, '2a']
                element_4 = component_table.loc[3, '2a']
                name = element_1 + '-' + element_2 + '-' + element_3 + '-' + element_4
            else:
                print('out of number! Please recheck the file!')

            property_together = pd.DataFrame()

            # for property_dict in property_data_list:
            for properties in element_properties.columns.tolist():

                delta_P_list = list()

                for series in component_table.values:

                    sequence_new = make_new_sequence(series)

                    df_center, df_neighbour, df_areas, surface_areas = neighbour_atom(sequence_new)

                    df_center_values, df_neighbour_values = add_property(df_center, df_neighbour, properties)

                    delta_P = calculate_property(df_center_values, df_neighbour_values, df_areas, surface_areas)

                    delta_P_list.append(delta_P)

                col_list = []
                for col in ['2a', '4f', '8i1', '8i2', '8j']:
                    name_temp = 'delta' + '_' + properties + '_' + col
                    col_list.append(name_temp)
                # print(property_mean_list)
                data = np.array(delta_P_list)
                # print(data)
                df_temp = pd.DataFrame(data=data, columns=col_list)
                property_together = pd.concat([property_together, df_temp], axis=1)

            finish_attribute = time.time()
            print('%s is over, 耗时：%0.2f (min)' % (attributes, (finish_attribute - start_attribute)/60))

            property_together.index = range(property_together.shape[0])
            # property_together.to_csv('./%s_local.csv' % name)

            df_occupancy = occupancy_of_sublattice(system, attributes)
            df_all = pd.concat([df_target, df_occupancy, property_together], axis=1)

            if system == 'Cr-Fe-Co-Ni':
                df_all.drop(labels=[0, 1, 2, 3], axis=0, inplace=True)
            else:
                df_all.drop(labels=[0, 1, 2], axis=0, inplace=True)

            df_all.to_csv('./%s_%s_%s.csv' % (system, attributes, target_name))
        finish_system = time.time()
        print('%s is over! time：%.2f (min)' % (system, (finish_system - start_system)/60))

    finish1 = time.time()
    print('all systems is over! time：%0.2f (hour)' % ((finish1 - start1)/3600))



