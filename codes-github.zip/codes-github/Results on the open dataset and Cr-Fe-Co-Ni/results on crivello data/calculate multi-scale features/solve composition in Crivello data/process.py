import pandas as pd
import numpy as np

def count_num():
    pass


if __name__ == "__main__":
    df_data = pd.read_csv('./Crivello.csv', index_col=0)
    






