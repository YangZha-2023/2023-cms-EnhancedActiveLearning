from sklearn.model_selection import KFold
from sklearn.model_selection import GridSearchCV
import pandas as pd
import numpy as np
import time
from sklearn.svm import SVR
from sklearn.decomposition import PCA
from sklearn.model_selection import cross_validate, cross_val_predict
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error
from sklearn.preprocessing import StandardScaler


def read_csv(_system, _attributes, _target_name):
    _data = pd.read_csv('../data/%s_%s_%s.csv' % (_system, _attributes, _target_name), index_col=0)
    _x = _data.iloc[:, 1:].values
    _y = _data.iloc[:, 0].values

    return _x, _y


def standard_scaler(_x: object, _y: object) -> object:

    _scaler_x = StandardScaler().fit(_x)
    _std_x = _scaler_x.transform(_x)
    _x_pca, _x_pca_mle = pca(_std_x, _std_x)

    _scaler_y = StandardScaler().fit(_y.reshape(-1, 1))
    _std_y = _scaler_y.transform(_y.reshape(-1, 1))
    return _scaler_x, _x_pca, _scaler_y, _std_y


def pca(_x1, _x2):

    pca_mle = PCA(n_components='mle').fit(_x1)
    _x_pca = pca_mle.transform(_x2)

    return _x_pca, pca_mle


def train_model(_std_x, _std_y, _cv, _param):
    # _x_pca, _x_pca_mle = pca(_std_x, _std_x)

    gs = GridSearchCV(estimator=SVR()
                      , param_grid=_param
                      , scoring='neg_mean_squared_error'
                      , n_jobs=njobs
                      , cv=_cv
                      , refit=True  # 模型会使用最佳参数在fit一遍全数据
                      )
    criteria_new_svr = gs.fit(_std_x, _std_y.ravel())

    return criteria_new_svr.best_params_


def save_results(_best_param, _y, _scaler_y, _std_x, _std_y, _cv, _indicators):
    best_model = SVR(epsilon=_best_param['epsilon'],
                     gamma=_best_param['gamma'],
                     C=_best_param['C'])

    _indicatorslist_on_test = []
    _indicatorslist_on_original = []

    for scoring in _indicators:
        best_param_result = cross_validate(best_model, _std_x, _std_y.ravel(), cv=_cv
                                           , n_jobs=njobs
                                           , return_train_score=True
                                           , scoring=scoring
                                           )
        _result = np.abs(best_param_result['test_score'].mean())
        _indicatorslist_on_test.append(_result)

    cv_pred = cross_val_predict(best_model, _std_x, _std_y.ravel(), cv=_cv)

    y_cv_pred = _scaler_y.inverse_transform(cv_pred)

    if gl_picture_switch is True:
        df_picture = pd.DataFrame(data=np.concatenate((_y.reshape(-1, 1), y_cv_pred.reshape(-1, 1)), axis=1),
                                  index=range(_y.shape[0]), columns=['y_true', 'y_predict'])
        df_picture.to_csv('../picture/%s_%s_for_picture.csv' % (system, attributes))

    # this version need to add ternary data to another csv, 统一转化成Kj/mol*atom
    for _indicator in _indicators:
        if _indicator == 'r2':
            _indicatorslist_on_original.append(r2_score(_y, y_cv_pred))

        elif _indicator == 'neg_mean_absolute_error':
            _indicatorslist_on_original.append(mean_absolute_error(_y, y_cv_pred))

        elif _indicator == 'neg_root_mean_squared_error':
            _indicatorslist_on_original.append(np.sqrt(mean_squared_error(_y, y_cv_pred)))

        elif _indicator == 'neg_mean_absolute_percentage_error':
            _indicatorslist_on_original.append(mean_absolute_percentage_error(_y, y_cv_pred))

    _indicatorslist_on_original = np.array(_indicatorslist_on_original)

    _indicatorslist_on_test = np.array(_indicatorslist_on_test)

    return _indicatorslist_on_test, _indicatorslist_on_original


if __name__ == "__main__":

    system_list = ['train']
    attributes_list = ['ORI']
    gl_target_name = 'deltaH'
    njobs = 18
    gl_picture_switch = True

    gl_cv = KFold(n_splits=10, shuffle=True, random_state=0)
    gl_indicators = ['r2', 'neg_mean_absolute_error',
                     'neg_root_mean_squared_error', 'neg_mean_absolute_percentage_error']

    c_range = np.linspace(5, 15, 5)

    param_dict = {'epsilon': [0.01],
                  'gamma': np.logspace(-3, -2, 10),
                  'C': c_range}

    # save all results
    results_for_all = pd.DataFrame()
    # save results on binary and ternary
    results_for_bin_ter = pd.DataFrame()
    # save results on binary and ternary on UD
    results_for_UD_bin_ter = pd.DataFrame()

    # save params to evaluate the param_range
    df_param = pd.DataFrame()

    time_for_all_start = time.time()

    for system in system_list:
        time_for_system_start = time.time()

        # save one system results for all data
        df_temp = pd.DataFrame()
        # save one system results for ter
        df_temp_bin_ter = pd.DataFrame()

        for attributes in attributes_list:
            time_for_attribute_start = time.time()
            x, y = read_csv(system, attributes, gl_target_name)

            scaler_x, std_x, scaler_y, std_y = standard_scaler(x, y)

            best_params = train_model(std_x, std_y, gl_cv, param_dict)

            indicatorslist_on_test, indicatorslist_on_original = save_results(best_params, y, scaler_y,
                                                                              std_x, std_y, gl_cv, gl_indicators)

            once_result = np.concatenate((indicatorslist_on_test, indicatorslist_on_original))

            # save params to evaluate the param_range
            data = []
            for values in best_params.values():
                data.append(values)
            df_param_ = pd.DataFrame(data=np.array(data).reshape(1, -1), columns=best_params.keys(),
                                     index=[system + '_' + attributes])
            df_param = pd.concat([df_param, df_param_], axis=0)

            # save results on all data
            col = []
            col.extend(gl_indicators)
            for indicator in gl_indicators:
                col.append(indicator + '_original')
            once_df = pd.DataFrame(data=once_result.reshape(1, -1),
                                   index=[system + '_' + attributes],
                                   columns=col)
            results_for_all = pd.concat([results_for_all, once_df], axis=0)

            time_for_attribute_end = (time.time() - time_for_attribute_start) / 60
            print('attributes %s is over! spend time: %f (min)' % (attributes, time_for_attribute_end))
            with open('processing.txt', 'a') as f:
                f.write('attributes %s is over! spend time: %f (min)\n' % (attributes, time_for_attribute_end))

        time_for_system_end = (time.time() - time_for_system_start) / 60
        print('system %s is over! spend time: %f (min)' % (system, time_for_system_end))
        with open('processing.txt', 'a') as f:
            f.write('system %s is over! spend time: %f (min)\n' % (system, time_for_system_end))

    time_for_all_end = (time.time() - time_for_all_start) / 3600
    print('all validations are over! spend time: %f (hour)' % time_for_all_end)
    with open('processing.txt', 'a') as f:
        f.write('all validations are over! spend time: %f (hour)\n' % time_for_all_end)

    results_for_all.to_csv('../results/results.csv')

    # save all system param
    df_param.to_csv('../param/params.csv')
